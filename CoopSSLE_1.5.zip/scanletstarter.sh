#!/bin/sh
set +o verbose
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
#
# Information: Scanletstarter
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        24.02.2009 V0.8 DCA   Erstdraft ab Windows-Version
#        17.03.2009 V0.9 DCA   Komplette �berarbeitung
#        19.03.2009 V1.0 DCA   Anpassungen ping-Befehl im switcher.sh und rsync in sshrobocopy.sh
#        19.03.2009 V1.1 DCA   Check f�r root privilege eingebaut
#        21.03.2009 V1.2 DCA   Bugfix bei Info_MachineBUSY, direkter Start des scanletjob.sh als root
#        22.07.2009 V1.3 DCA   Dynamisierung Scanletname
#        27.07.2009 V1.4 DCA   authentication Modi expect/create_ssh_rsa/expectless, debug, Remotecleanup
#
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
writeline()
# -------------------------------------------------------------------------------------------------------------
{
echo "$(date +"%d.%m.%Y %H:%M:%S")": $@
}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
raiseerror()
# -------------------------------------------------------------------------------------------------------------
{
error=$1
writeline $error
if [ ! "$logfiletmp" = "" ]; then
	if [ -f "$logfiletmp" ]; then
		(writeline $error)											>>"$logfiletmp"
		writeline $error
		read -p "press a key."
	fi
else
	writeline $error
	read -p "press a key."
fi
exit 1
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
header()
# -------------------------------------------------------------------------------------------------------------
{
echo -en "\033[34;1m"
echo --------------------------------------
echo Coop Scanlet for Suse Linux Enterprise
echo --------------------------------------
echo System information
cat /etc/SuSE-release
uname -a
echo -en "\033[0m"

}
# -------------------------------------------------------------------------------------------------------------



# -------------------------------------------------------------------------------------------------------------
initialization()
# -------------------------------------------------------------------------------------------------------------
{
thisbash="scanletstarter.sh"
rootdir=$PWD
scanletname=${PWD##*/}

# authentication=expect
# authentication=create_ssh_rsa
# authentication=expectless
authentication=expectless

debug=1

temppath=$rootdir/tmp
if [ -d "$temppath" ]; then
	rm -r -f "$temppath"
fi
mkdir -p "$temppath"

toolsdirname=tools
rscriptsdirname=remotescripts
rtoolsdirname=remotetools

toolsroot=$rootdir/$toolsdirname
if [ ! -d "$toolsroot" ]; then
	raiseerror "'$toolsroot' does not exist!"
fi

rtoolsroot=$rootdir/$rtoolsdirname
if [ ! -d $rtoolsroot ]; then
	raiseerror "'$rscriptsroot' does not exist!"
fi

rscriptsroot=$rootdir/$rscriptsdirname
if [ ! -d $rscriptsroot ]; then
	raiseerror "'$rscriptsroot' does not exist!"
fi

switcherfilename=switcher.sh
switcherfile=$toolsroot/$switcherfilename
if [ ! -f "$switcherfile" ]; then
	raiseerror "'$switcherfile' does not exist!"
fi

sshrobocopyfilename=sshrobocopy.sh
if [ "$authentication" == "expectless" ]; then
	sshrobocopyfilename=sshrobocopy-expectless.sh
fi
sshrobocopyfile=$toolsroot/$sshrobocopyfilename
if [ ! -f "$sshrobocopyfile" ]; then
	raiseerror "'$sshrobocopyfile' does not exist!"
fi

sshloginfilename=sshlogin.sh
sshloginfile=$toolsroot/$sshloginfilename
if [ ! -f "$sshloginfile" ]; then
	raiseerror "'$sshloginfile' does not exist!"
fi

remotescanletfilename=remotescanlet.sh
remotescanletfile=$rtoolsroot/$remotescanletfilename
if [ ! -f "$remotescanletfile" ]; then
	raiseerror "'$remotescanletfile' does not exist!"
fi

remotesuloginfilename=sulogin.sh
if [ "$authentication" == "expectless" ]; then
	remotesuloginfilename=sulogin-expectless.sh
fi
remotesuloginfile=$rtoolsroot/$remotesuloginfilename
if [ ! -f "$remotesuloginfile" ]; then
	raiseerror "'$remotesuloginfile' does not exist!"
fi

remotecroncmdfilename=croncmd.sh
remotecroncmdfile=$rtoolsroot/$remotecroncmdfilename
if [ ! -f "$remotecroncmdfile" ]; then
	raiseerror "'$remotecroncmdfile' does not exist!"
fi

scanletjobfilename=scanletjob.sh
scanletjobfile=$rscriptsroot/$scanletjobfilename
if [ ! -f "$scanletjobfile" ]; then
	raiseerror "'$scanletjobfile' does not exist!"
fi

username=mgmadmin
password=sleposadmin
distrsrv=$HOSTNAME

sshkey_rsa_private=id_rsa
sshkey_rsa_public=id_rsa.pub

activatecertificatefilename=activatecertificate.sh
activatecertificatefile=$rtoolsroot/$activatecertificatefilename
if [ ! -f "$activatecertificatefile" ]; then
	raiseerror "'$activatecertificatefile' does not exist!"
fi

}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
settings()
# -------------------------------------------------------------------------------------------------------------
{
writeline settings

# logfile specific definitions
logfilename=log.out
errorlogfilename=err.out
logfilenametmp=$logfilename.tmp

logfile=$rootdir/$logfilename
errorlogfile=$rootdir/$errorlogfilename

pruningage=10
pruning $errorlogfile $pruningage
pruning $logfile $pruningage

logfiletmp=$rootdir/$logfilenametmp
if [ -f "$logfiletmp" ]; then
	rm -f "$logfiletmp"
fi

delimiter=";"

# thread rotator specific information
separatecollectingtagname=separatecollecting.tag
separatecollectingtagfile=$rootdir/$separatecollectingtagname
maxslots=10

# slot specific definitions
slotlogfilename=log.out
sloterrorlogfilename=err.out
slotstatusfilename=status.sh
slotendtagfilename=end.tag

# remote specific definitions
remotestartfilename=scanletjob.sh
remotelogfilename=remotelog.out
remoteerrorlogfilename=remoteerr.out
remotecfgfilename=cfg_scanletjob.sh
remotedonetagfilename=remotedone.tag
remotecleanupfilename=remotecleanup.sh
remotetemppath=/tmp
remotetoolspath=$remotetemppath/tools
remotescanletpath=$remotetemppath/$scanletname

cleanupremotepath="Y"

}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
pruning()
# -------------------------------------------------------------------------------------------------------------
{
writeline pruning $1: not implemented yet.
# TODO
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
threadslot()
# -------------------------------------------------------------------------------------------------------------
{
slotID=$1
writeline create slot $slotID ...

pathslotID=$temppath/$slotID
slotinitfilename=slotinit.sh

mkdir -p "$pathslotID" >/dev/null
mkdir -p  $pathslotID/$toolsdirname >/dev/null
mkdir -p  $pathslotID/$rtoolsdirname >/dev/null
mkdir -p  $pathslotID/$rscriptsdirname >/dev/null
cp -a -f $toolsroot/* $pathslotID/$toolsdirname  >/dev/null
cp -a -f $rtoolsroot/* $pathslotID/$rtoolsdirname >/dev/null
cp -a -f $rscriptsroot/* $pathslotID/$rscriptsdirname >/dev/null

chmod a+x "$pathslotID/$toolsdirname/$switcherfilename" >/dev/null
chmod a+x "$pathslotID/$toolsdirname/$sshloginfilename" >/dev/null
chmod a+x "$pathslotID/$toolsdirname/$sshrobocopyfilename" >/dev/null
chmod a+x "$pathslotID/$rtoolsdirname/$remotescanletfilename" >/dev/null
chmod a+x "$pathslotID/$rtoolsdirname/$remotesuloginfilename" >/dev/null
chmod a+x "$pathslotID/$rscriptsdirname/$scanletjobfilename" >/dev/null

slotinitfile=$pathslotID/$slotinitfilename
echo #!/bin/sh										>"$slotinitfile"
echo # Do not delete!									>>"$slotinitfile"
echo scanletname=$scanletname								>>"$slotinitfile"

echo toolsdirname=$toolsdirname								>>"$slotinitfile"
echo rtoolsdirname=$rtoolsdirname							>>"$slotinitfile"
echo rscriptsdirname=$rscriptsdirname							>>"$slotinitfile"

echo slotID=$slotID									>>"$slotinitfile"
echo pathslotID=$pathslotID								>>"$slotinitfile"
echo slotinitfilename=$slotinitfilename							>>"$slotinitfile"

echo slotstatusfilename=$slotstatusfilename						>>"$slotinitfile"
echo slotlogfilename=$slotlogfilename							>>"$slotinitfile"
echo sloterrorlogfilename=$sloterrorlogfilename						>>"$slotinitfile"
echo slotendtagfilename=$slotendtagfilename						>>"$slotinitfile"

echo remotecroncmdfilename=$remotecroncmdfilename					>>"$slotinitfile"
echo remotesuloginfilename=$remotesuloginfilename					>>"$slotinitfile"
echo remotestartfilename=$remotestartfilename						>>"$slotinitfile"
echo remotelogfilename=$remotelogfilename						>>"$slotinitfile"
echo remoteerrorlogfilename=$remoteerrorlogfilename					>>"$slotinitfile"
echo remotecfgfilename=$remotecfgfilename						>>"$slotinitfile"
echo remotedonetagfilename=$remotedonetagfilename					>>"$slotinitfile"
echo remotetoolspath=$remotetoolspath							>>"$slotinitfile"
echo remotescanletpath=$remotescanletpath						>>"$slotinitfile"
echo remotecleanupfilename=$remotecleanupfilename					>>"$slotinitfile"
echo activatecertificatefilename=$activatecertificatefilename				>>"$slotinitfile"

echo sshrobocopyfilename=$sshrobocopyfilename						>>"$slotinitfile"
echo sshloginfilename=$sshloginfilename							>>"$slotinitfile"
echo remotescanletfilename=$remotescanletfilename					>>"$slotinitfile"
echo scanletjobfilename=$scanletjobfilename						>>"$slotinitfile"

echo username=$username									>>"$slotinitfile"
echo password=$password									>>"$slotinitfile"
echo distrsrv=$distrsrv									>>"$slotinitfile"
echo authentication=$authentication							>>"$slotinitfile"
echo sshkey_rsa_public=$sshkey_rsa_public						>>"$slotinitfile"
echo delimiter=\"$delimiter\"								>>"$slotinitfile"

echo cleanupremotepath=$cleanupremotepath						>>"$slotinitfile"


chmod a+x "$slotinitfile" >/dev/null

nohup "$pathslotID/$toolsdirname/$switcherfilename" "$slotinitfile" &>"$pathslotID/$slotlogfilename" &
PID=$!
echo $PID	>$slotinitfile.pid
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
createthreads()
# -------------------------------------------------------------------------------------------------------------
{
writeline create slots ...
for a in `seq $maxslots`
do
	threadslot $a
done
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
threadswitchprocessing()
# -------------------------------------------------------------------------------------------------------------
{
	while [ 1 ]
	do
		local statusflagfile=$temppath/$slotpointer/$slotstatusfilename
		if [ -f "$statusflagfile" ]; then
			frisbeeslice=$[frisbeeslice+1]
			if [ "$slotpointer" -ge "$maxslots" ]; then
				slotpointer=0
				if [ "$frisbeeslice" -gt "0" ]; then
					sleep 2
					frisbeeslice=0
				fi
			fi
			slotpointer=$[slotpointer+1]
		else
			echo #!/bin/sh			>"$statusflagfile"
			echo modus=$threadrotatormode	>>"$statusflagfile"
			echo ipaddr=$ipaddr		>>"$statusflagfile"
			echo $threadrotatormode: $ipaddr in slot $slotpointer
			frisbeeslice=0
			break
		fi
	done
}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
threadswitch()
# -------------------------------------------------------------------------------------------------------------
{
ipaddr=$1
threadrotatormode=$2

local slotpointer=1
local frisbeeslice=0

if [ "$threadrotatormode" = "DISTRIBUTING" ]; then
	threadswitchprocessing
else
	if [ -f "$errorlogfile" ]; then
		cat $errorlogfile| grep -i "$ipaddr" >/dev/null
		if [ $? -gt 0 ]; then
			threadswitchprocessing
		else
			writeline Server $ipaddr failed already in mode DISTRIBUTING!
		fi
	else
		threadswitchprocessing
	fi
fi
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
waitthreadrotatorend()
# -------------------------------------------------------------------------------------------------------------
{
threadrotatormode=$1
waitmaxslotending=600
waitslotending=0
writeline Waiting until all threads are finished in mode $threadrotatormode ...
while [ 1 ];
do
	if [ $waitslotending -ge $waitmaxslotending ]; then
		allslots="TIMEOUT"
		break
	else
		waitslotending=$[waitslotending+1]
		sleep 1
		allslots="IDLE"
		for a in `seq $maxslots`
		do
			if [ -f "$temppath/$a/$slotstatusfilename" ]; then
				allslots=BUSY
				break
			fi
		done
		if [ $allslots = "IDLE" ]; then
			break
		fi
	fi
done

if [ $allslots = "TIMEOUT" ]; then
	writeline Warning: Some threads are still running!
else
	writeline All threads finished in mode $threadrotatormode.
fi
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
writeerrorlog()
# -------------------------------------------------------------------------------------------------------------
{
for a in `seq $maxslots`
do
	if [ -f "$temppath/$a/$sloterrorlogfilename" ]; then
		cat $temppath/$a/$sloterrorlogfilename								>>$errorlogfile
		rm -f $temppath/$a/$sloterrorlogfilename
	fi
done
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
distribute()
# -------------------------------------------------------------------------------------------------------------
{
threadrotatormode=DISTRIBUTING
writeline Processing files with thread rotator in mode $threadrotatormode ...
for file in `cat "$rootdir/list"`
do
    threadswitch $file $threadrotatormode
done
writeline Processing files with thread rotator in mode $threadrotatormode  done.
waitthreadrotatorend $threadrotatormode
writeerrorlog
}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
collect()
# -------------------------------------------------------------------------------------------------------------
{
threadrotatormode=COLLECTING
writeline Processing files with thread rotator in mode $threadrotatormode ...
for file in `cat "$rootdir/list"`
do
    threadswitch $file $threadrotatormode
done
writeline Processing files with thread rotator in mode $threadrotatormode  done.
waitthreadrotatorend $threadrotatormode
writeerrorlog
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
destroythreads()
# -------------------------------------------------------------------------------------------------------------
{
for a in `seq $maxslots`
do
	echo DONE>$temppath/$a/$slotendtagfilename
done
sleep 1
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
mail()
# -------------------------------------------------------------------------------------------------------------
{
if [ -f "$errorlogfile" ]; then
	mailattach=$rootdir/$scanletname.csv
	cp -f $errorlogfile $mailattach

	maildir=$toolsroot/mail
	# global customer specific variables
	. $maildir/mailcfg.sh

	messagebody=$maildir/mailinfo
	subject="CoopSSLE alert mail from $scanletname on $HOSTNAME"

	# http://caspian.dotconf.net/menu/Software/SendEmail/
	tar -xzvf $maildir/sendEmail-v1.55.tar.gz -C $maildir

	for recipient in `cat "$rootdir/recipients"`
	do
		perl $maildir/sendEmail-v1.55/sendEmail -f $sender -t $recipient -u $subject -o message-file=$messagebody -s $smtpserver:$smtpport -a $mailattach -o tls=auto
	done
fi

}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
create_sshkey_rsa()
# -------------------------------------------------------------------------------------------------------------
{
ssh-keygen -f $temppath/$sshkey_rsa_private -t rsa
# Nun m�sste ein private key und ein public key erstellt worden sein.
if [ -f "$temppath/$sshkey_rsa_public" ]; then
	if [ -d "/home/$username" ]; then
		if [ ! -d "/home/$username/.ssh" ]; then
			mkdir "/home/$username/.ssh"
			chown mgmadmin:users "/home/$username/.ssh"
		fi
		cp -f "$temppath/$sshkey_rsa_private" "/home/$username/.ssh"
		chown mgmadmin:users "/home/$username/.ssh/$sshkey_rsa_private"
		if [ $? -eq 0 ]; then
			cp -f "$temppath/$sshkey_rsa_public" "$rtoolsroot"
		fi
	fi
fi
}
# -------------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------------
cleanup()
# -------------------------------------------------------------------------------------------------------------
{
writeline cleanup
rm -r -f "$temppath"
}
# -------------------------------------------------------------------------------------------------------------




# -------------------------------------------------------------------------------------------------------------
# --------------------------------------------- main ----------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
trap 'normalplease'  1 2 3 15
# Siehe http://de.wikibooks.org/wiki/Linux-Kompendium:_Shellprogrammierung

header
ROOT_UID=0
if [ "$UID" -eq "$ROOT_UID" ]
then
	echo -en "\033[38;1m"
	initialization
	settings
	if [ "$authentication" == "create_ssh_rsa" ]; then
		create_sshkey_rsa
	fi
	createthreads
	distribute
	waittime=80
	writeline Waiting $waittime seconds between DISTRIBUTING and COLLECTING
	sleep $waittime
	collect
	destroythreads
	mail
	if [ "$debug" -eq "0" ]; then
		cleanup
	fi
else
	echo -en "\033[33;1m"
	echo CoopSSLE needs root privileges. Please switch to root context.
fi
echo -en "\033[0m"








