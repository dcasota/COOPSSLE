#!/bin/bash

# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
#
# Information: Remotecleanup-Skript
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        27.07.2009 V1.00 DCA   Ersterstellung
#
#
#
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------

# --------------------------------------------------------------------------------------------------------------
#  Startup
# --------------------------------------------------------------------------------------------------------------
CurrentPath=$PWD
FileToRun=$1

. "$FileToRun"

# Cleanup crontab
$remotetoolspath/$remotecroncmdfilename del "$remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotecleanupfilename $remotescanletpath/$slotinitfilename"


if [ "$remotedonetagfile" != "" ]; then
	if [ "$remotescanletpath" != "" ]; then
		if [ "$remotedonetagfilename" != "" ]; then
			if [ -f "$remotedonetagfile" ]; then
				rm -f $remotescanletpath/$remotedonetagfilename
			fi
		fi
	fi
fi

if [ "$remotescanletpath" != "" ]; then
	if [ "$cleanupremotepath" == "Y" ]; then
		rm -r -f $remotescanletpath
	fi
fi


