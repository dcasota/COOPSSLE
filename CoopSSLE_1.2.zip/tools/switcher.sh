#!/bin/bash


# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
#
# Information: Abarbeitungsmeccano pro Slot
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        24.02.2009 V1.00 DCA   Ersterstellung
#        17.03.2009 V2.00 DCA   �berarbeitung proceed-Routine
#        21.03.2009 V2.01 DCA   Bugfix Info_MachineBUSY
#
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------



# -------------------------------------------------------------------------------------------------------------
distributing()
# -------------------------------------------------------------------------------------------------------------
{
	# Mit rsync konnte keine Subverzeichnisstruktur-Kreierung erreicht werden.
	# Deswegen werde die notwendigen Verzeichnisse vorab erstellt.
	. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "mkdir -p $remotescanletpath"
	. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "mkdir -p $remotetoolspath"
	$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$rtoolsdirname/ $username@$ipaddr:$remotetoolspath $password
	if [ $? -eq 0 ]; then
		$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$rscriptsdirname/ $username@$ipaddr:$remotescanletpath $password
		if [ $? -eq 0 ]; then
			$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$slotinitfilename $username@$ipaddr:$remotescanletpath/$slotinitfilename $password
			if [ $? -eq 0 ]; then
				. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "nohup $remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotescanletfilename $remotescanletpath/$slotinitfilename"
				if [ $? -eq 0 ]; then
					echo Remote script successfully started.
				else
					echo Could not start remote script!
					echo $ipaddr,remotescript_notstarted					>>$pathslotID/$sloterrorlogfilename
				fi
			else
				echo Could not copy $remotescanletpath/$slotinitfilename to server $ipaddr!
				echo $ipaddr,slotinitfilename_notcopied						>>$pathslotID/$sloterrorlogfilename
			fi
		else
			echo Could not copy $rscriptsdirname to server $ipaddr!
			echo $ipaddr,rscriptsdir_notcopied							>>$pathslotID/$sloterrorlogfilename
		fi
	else
		echo Could not copy $rtoolsdirname to server $ipaddr!
		echo $ipaddr,rtoolsdir_notcopied								>>$pathslotID/$sloterrorlogfilename
	fi
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
collecting()
# -------------------------------------------------------------------------------------------------------------
{
	$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $username@$ipaddr:$remotescanletpath/$remotedonetagfilename $pathslotID/$remotedonetagfilename $password
	if [ -f "$pathslotID/$remotedonetagfilename" ]; then
		$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $username@$ipaddr:$remotescanletpath/$remoteerrorlogfilename $pathslotID/$remoteerrorlogfilename $password
		if [ -f "$pathslotID/$remoteerrorlogfilename" ]; then
			cat $pathslotID/$remoteerrorlogfilename						>>$pathslotID/$sloterrorlogfilename
			sleep 1
			rm -f $pathslotID/$remoteerrorlogfilename
		fi
	else
		echo $ipaddr,INFO_MachineBUSY								>>$pathslotID/$sloterrorlogfilename
	fi
	rm -f $pathslotID/$remotedonetagfilename
}
# -------------------------------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------------------------------
proceed()
# --------------------------------------------------------------------------------------------------------------
{
echo Pinging $ipaddr ...
ping -c 1 $ipaddr|grep -i "ttl=" > /dev/null
if [ $? -eq 0 ]; then
	echo Pinging $ipaddr successfully done.
	if [ "$modus" == "DISTRIBUTING" ]; then
		distributing
	else
		collecting
		$pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr rm "-f $remotescanletpath/$remotedonetagfilename"
		# $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr rm "-r -f $remotescanletpath"
	fi
else
	echo Link is offline.
	echo $ipaddr,offline_$modus										>>$pathslotID/$sloterrorlogfilename
fi
}
# --------------------------------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------------------------------

# evtl. von Nutzen
processID=$$

# Get slot information from initialization file
slotinitializationfile=$1
. "$slotinitializationfile"

slotendtagfile=$pathslotID/$slotendtagfilename
slotstatusflagfile=$pathslotID/$slotstatusfilename

slottmplogfile=$pathslotID/tmp.out

while [ 1 ]
do
	if [ -f "$slotstatusflagfile" ]; then
		sleep 1
		chmod a+x "$slotstatusflagfile"
		. "$slotstatusflagfile"
		proceed
		if [ -f "$slottmplogfile" ]; then
			cat "$slottmplogfile"
			rm -f "$slottmplogfile"
		fi
		rm -f "$slotstatusflagfile"
	else
		echo Slot $slotID is IDLE.
		sleep 1
	fi
	if [ -f "$slotendtagfile" ]; then
		break
	fi
done
