#!/bin/sh
smtpserver=miraculix.simplehosting.ch
smtpport=25
sender=coopssle@intersolutions.ch

