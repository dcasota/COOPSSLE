#!/bin/bash

username=$1
password=$2
ipaddr=$3
scriptname=$4

expect -c "set timeout 10;\
spawn -noecho ssh -o StrictHostKeyChecking=no $ipaddr -l $username \"$scriptname\";\
match_max 100000;\
expect *assword:*;\
send -- $password\r\n;\
expect eof;"


