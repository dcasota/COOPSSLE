#!/bin/sh


# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
#
# Information: Abarbeitungsmeccano pro Slot
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        24.02.2009 V1.00 DCA   Ersterstellung
#        17.03.2009 V2.00 DCA   �berarbeitung proceed-Routine
#        21.03.2009 V2.01 DCA   Bugfix Info_MachineBUSY
#        23.07.2009 V2.02 DCA   Delimiter von , auf ; ge�ndert
#        27.07.2009 V2.03 DCA   Delimiter dynamisiert
#        29.07.2009 V2.10 DCA   Einbau zertifikatsbasierende Methode (expectless)
#
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
createremotestarter()
# -------------------------------------------------------------------------------------------------------------
{
remotehelper=$pathslotID/$rtoolsdirname/remotehelper.sh
echo #!/bin/sh>$remotehelper
echo . $remotetoolspath/remotestarter.sh \& >>$remotehelper
chmod a+x $remotehelper

remotestarter=$pathslotID/$rtoolsdirname/remotestarter.sh
echo #!/bin/sh>$remotestarter
echo nohup $remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotescanletfilename $remotescanletpath/$slotinitfilename >>$remotestarter
chmod a+x $remotestarter

sshhelper=$pathslotID/sshhelper.sh
echo #!/bin/sh>$sshhelper
echo ssh -o StrictHostKeyChecking=no $ipaddr \". $remotetoolspath/remotehelper.sh\ \&\" >>$sshhelper
chmod a+x $sshhelper
chown mgmadmin:users $sshhelper
}



# -------------------------------------------------------------------------------------------------------------
distributing()
# -------------------------------------------------------------------------------------------------------------
{
	# Mit rsync konnte keine Subverzeichnisstruktur-Kreierung erreicht werden.
	# Deswegen werde die notwendigen Verzeichnisse vorab erstellt.
	if [ "$authentication" == "expectless" ]; then
		su $username --command="ssh -o StrictHostKeyChecking=no $ipaddr \"mkdir -p $remotescanletpath\""
	else
		. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "mkdir -p $remotescanletpath"
	fi
	if [ "$authentication" == "expectless" ]; then
		su $username --command="ssh -o StrictHostKeyChecking=no $ipaddr \"mkdir -p $remotescanletpath\""
	else
		. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "mkdir -p $remotetoolspath"
	fi

	createremotestarter

	$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$rtoolsdirname/ $username@$ipaddr:$remotetoolspath $username $password
	if [ $? -eq 0 ]; then
		$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$rscriptsdirname/ $username@$ipaddr:$remotescanletpath $username $password
		if [ $? -eq 0 ]; then
			$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $pathslotID/$slotinitfilename $username@$ipaddr:$remotescanletpath/$slotinitfilename $username $password
			if [ $? -eq 0 ]; then
				# echo Starting remote scanlet script ...
				if [ "$authentication" == "expectless" ]; then
					su $username --command=". $sshhelper \&"
				else
					. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "nohup $remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotescanletfilename $remotescanletpath/$slotinitfilename"
				fi
				if [ $? -eq 0 ]; then
					echo Remote scanlet script successfully started.
				else
					echo Could not start remote scanlet script!
					echo "$ipaddr"$delimiter"remotescanletscript_notstarted"		>>$pathslotID/$sloterrorlogfilename
				fi
			else
				echo Could not copy $remotescanletpath/$slotinitfilename to server $ipaddr!
				echo "$ipaddr"$delimiter"slotinitfilename_notcopied"				>>$pathslotID/$sloterrorlogfilename
			fi
		else
			echo Could not copy $rscriptsdirname to server $ipaddr!
			echo "$ipaddr"$delimiter"rscriptsdir_notcopied"						>>$pathslotID/$sloterrorlogfilename
		fi
	else
		echo Could not copy $rtoolsdirname to server $ipaddr!
		echo "$ipaddr"$delimiter"rtoolsdir_notcopied"							>>$pathslotID/$sloterrorlogfilename
	fi
}
# -------------------------------------------------------------------------------------------------------------


# -------------------------------------------------------------------------------------------------------------
collecting()
# -------------------------------------------------------------------------------------------------------------
{
	$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $username@$ipaddr:$remotescanletpath/$remotedonetagfilename $pathslotID/$remotedonetagfilename $username $password
	if [ -f "$pathslotID/$remotedonetagfilename" ]; then
		$pathslotID/$toolsdirname/$sshrobocopyfilename $slottmplogfile $username@$ipaddr:$remotescanletpath/$remoteerrorlogfilename $pathslotID/$remoteerrorlogfilename $username $password
		if [ -f "$pathslotID/$remoteerrorlogfilename" ]; then
			cat $pathslotID/$remoteerrorlogfilename							>>$pathslotID/$sloterrorlogfilename
			sleep 1
			rm -f $pathslotID/$remoteerrorlogfilename
		fi
	else
		echo "$ipaddr"$delimiter"INFO_MachineBUSY"							>>$pathslotID/$sloterrorlogfilename
	fi
	rm -f $pathslotID/$remotedonetagfilename
}
# -------------------------------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------------------------------
proceed()
# --------------------------------------------------------------------------------------------------------------
{
echo Pinging $ipaddr ...
ping -c 1 $ipaddr|grep -i "ttl=" > /dev/null
if [ $? -eq 0 ]; then
	echo Pinging $ipaddr successfully done.
	if [ "$modus" == "DISTRIBUTING" ]; then
		distributing
	else
		collecting
		# echo Starting remote cleanup script ...
		if [ "$authentication" == "expectless" ]; then
			su $username --command="ssh -o StrictHostKeyChecking=no $ipaddr \"nohup $remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotecleanupfilename $remotescanletpath/$slotinitfilename\""  &
		else
			. $pathslotID/$toolsdirname/$sshloginfilename $username $password $ipaddr "nohup $remotetoolspath/$remotesuloginfilename $remotetoolspath/$remotecleanupfilename $remotescanletpath/$slotinitfilename"
		fi
		if [ $? -eq 0 ]; then
			echo Remote cleanup script successfully started.
		else
			echo Could not start remote cleanup script!
			echo "$ipaddr"$delimiter"remotecleanupscript_notstarted"				>>$pathslotID/$sloterrorlogfilename
		fi
	fi
else
	echo Link is offline.
	echo "$ipaddr"$delimiter"offline_$modus"								>>$pathslotID/$sloterrorlogfilename
fi
}
# --------------------------------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------------------------------

# evtl. von Nutzen
processID=$$

# Get slot information from initialization file
slotinitializationfile=$1
. "$slotinitializationfile"

slotendtagfile=$pathslotID/$slotendtagfilename
slotstatusflagfile=$pathslotID/$slotstatusfilename

slottmplogfile=$pathslotID/tmp.out

while [ 1 ]
do
	if [ -f "$slotstatusflagfile" ]; then
		sleep 1
		chmod a+x "$slotstatusflagfile"
		. "$slotstatusflagfile"
		proceed
		if [ -f "$slottmplogfile" ]; then
			cat "$slottmplogfile"
			rm -f "$slottmplogfile"
		fi
		rm -f "$slotstatusflagfile"
	else
		echo Slot $slotID is IDLE.
		sleep 1
	fi
	if [ -f "$slotendtagfile" ]; then
		break
	fi
done
