#!/bin/sh
smtpserver=mail.coop.ch
smtpport=25
sender=coopssle@coop.ch

