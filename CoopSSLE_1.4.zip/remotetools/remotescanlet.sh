#!/bin/bash

# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
#
# Information: Remotscanlet-Skript, welches dann den Scanletjob aufruft.
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        17.03.2009 V1.00 DCA   Ersterstellung
#        19.03.2009 V1.01 DCA   Aufruf des scanletjobs mittels sudo
#        29.07.2009 V1.02 DCA   Ein neues Zertifikat kann gleichzeitig installiert werden.
#
#
#
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------

# --------------------------------------------------------------------------------------------------------------
#  Startup
# --------------------------------------------------------------------------------------------------------------
CurrentPath=$PWD
FileToRun=$1

. "$FileToRun"

remotedonetagfile=$remotescanletpath/$remotedonetagfilename
remoteerrorlogfile=$remotescanletpath/$remoteerrorlogfilename
remotelogfile=$remotescanletpath/$remotelogfilename

if [ -f "$remotedonetagfile" ]; then
	sleep 30
fi
if [ -f "$remotedonetagfile" ]; then
	rm -f "$remotedonetagfile"
fi

#  L�schen der Steuerungsfiles, falls vorhanden
if [ -f "$remotelogfile" ]; then
	rm -f "$remotelogfile"
fi

if [ -f "$remoteerrorlogfile" ]; then
	rm -f "$remoteerrorlogfile"
fi
# --------------------------------------------------------------------------------------------------------------


# --------------------------------------------------------------------------------------------------------------
# CallCustomBatch
# --------------------------------------------------------------------------------------------------------------
#  Kopieren der Remotetools ins Scanletverzeichnis
cp -a -f $remotetoolspath/* $remotescanletpath
sleep 1

if [ "$authentication" == "create_ssh_rsa" ]; then
	. "$remotescanletpath/$activatecertificatefilename"
fi

. "$remotescanletpath/$remotestartfilename"  &>"$remotelogfile"


echo DONE>"$remotedonetagfile"
# --------------------------------------------------------------------------------------------------------------



