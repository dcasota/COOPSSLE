#!/bin/bash

# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
#
# Information: Dieses Skript installiert das neue RSA-Zertifikat.
#
# Autor(en): Daniel Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
# Aktuelle Version: dd.mm.yyyy (K�rzel)
#
# History:
#        27.07.2009 V1.00 DCA   Ersterstellung
#        29.07.2009 V1.01 DCA   Pr�zisierung Text: Nur rsa
#
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------


# der aktuelle eingeloggte user ist root. Daher wird explizit $username verwendet.
if [ ! -d "/home/$username" ]; then
	echo "No /home/$username  found!"
else
	if [ ! -d "/home/$username/.ssh" ]; then
		mkdir /home/$username/.ssh
		chown mgmadmin:users /home/$username/.ssh
	fi
	cp -f $remotescanletpath/$sshkey_rsa_public /home/$username/.ssh
	chown mgmadmin:users /home/$username/.ssh/$sshkey_rsa_public
	cat /home/$username/.ssh/$sshkey_rsa_public >>/home/$username/.ssh/authorized_keys
	# Restanz aufgrund copy im remotescanlet.sh
	rm -f $remotetoolspath/$sshkey_rsa_public
fi

