#!/bin/bash

# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
#
# Information: Add an cron entry
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        05.08.2009 V1.00 DCA   Ersterstellung
#
#
#
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------

COMMAND=$1
CRONLINE=$2

if [ "$CRONLINE" != "" ]; then

	RANDOM=$$
	cronfile=/tmp/cron.$RANDOM.sh

	if [ "$COMMAND" == "add" ]; then
		# create cron command file
		echo "#!/bin/sh"												>$cronfile
		echo "EDITOR=ed"												>>$cronfile
		echo "export EDITOR"												>>$cronfile
		echo "crontab -e << EOF > /dev/null"										>>$cronfile
		echo "a"													>>$cronfile
		echo "$CRONLINE"												>>$cronfile
		echo "."													>>$cronfile
		echo "w"													>>$cronfile
		echo "q"													>>$cronfile
		echo "EOF"													>>$cronfile
		echo "EDITOR=vi"												>>$cronfile
		echo "export EDITOR"												>>$cronfile
	fi
	if [ "$COMMAND" == "del" ]; then
		# create cron command file
		echo "#!/bin/sh"												>$cronfile
		echo "currentpath=\$PWD"											>>$cronfile
		echo "filename1=\${PWD##*/}"											>>$cronfile
		echo "filename2=\$filename1.\$RANDOM"										>>$cronfile
		echo "filename3=\$filename1.\$RANDOM.tmp"									>>$cronfile
		echo "crontab -l >\$currentpath/\$filename1"									>>$cronfile
		echo "grep -v \"$CRONLINE\" \$filename1 >\$filename2"								>>$cronfile
		echo "grep -v \"# \" \$filename2 >\$filename3"									>>$cronfile
		echo "crontab \$filename3"											>>$cronfile
		echo "rm -f \$filename1"											>>$cronfile
		echo "rm -f \$filename2"											>>$cronfile
		echo "rm -f \$filename3"											>>$cronfile
	fi
	if [ -f $cronfile ]; then
		chmod a+x $cronfile
		# Execute the cron command file
		if [ -f $cronfile ]; then
			. $cronfile
			if [ $? -eq 0 ]; then
				rm -f $cronfile
			fi
		fi
	fi
fi

