#!/bin/sh

# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
#
# Information: Remotestart eines Skripts via ssh
#
# Autor(en): D.Casota (DCA), daniel.casota@intersolutions.ch
#            InterSolutions GmbH, www.intersolutions.ch
#
#
# History:
#        19.03.2009 V1.00 DCA   Ersterstellung
#        28.07.2009 V1.01 DCA   �berarbeitung Parameter
#        05.08.2009 V1.02 DCA   $authentication als Unterscheidung hinzugef�gt, Kommentar hinzugef�gt
#
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------
# -------------------------------------------------------------------------------------------------------------

authentication=$1

if [ "$authentication" != "expectless" ]; then

	username=$2
	password=$3
	ipaddr=$4
	scriptname=$5

	expect -c "set timeout 10;\
	spawn -noecho ssh -o StrictHostKeyChecking=no $ipaddr -l $username \"$scriptname\";\
	match_max 100000;\
	expect *assword:*;\
	send -- $password\r\n;\
	expect eof;"
else
	username=$2
	password=$3
	ipaddr=$4
	scriptname=$5
	ssh -o StrictHostKeyChecking=no $ipaddr -l $username "$scriptname"
fi

